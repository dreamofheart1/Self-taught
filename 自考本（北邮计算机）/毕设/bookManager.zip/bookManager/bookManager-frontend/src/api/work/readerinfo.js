import request from '@/utils/request'

// 查询读者列表
export function listReaderinfo(query) {
  return request({
    url: '/work/readerinfo/list',
    method: 'get',
    params: query
  })
}

// 查询读者详细
export function getReaderinfo(id) {
  return request({
    url: '/work/readerinfo/' + id,
    method: 'get'
  })
}

// 新增读者
export function addReaderinfo(data) {
  return request({
    url: '/work/readerinfo',
    method: 'post',
    data: data
  })
}

// 修改读者
export function updateReaderinfo(data) {
  return request({
    url: '/work/readerinfo',
    method: 'put',
    data: data
  })
}

// 删除读者
export function delReaderinfo(id) {
  return request({
    url: '/work/readerinfo/' + id,
    method: 'delete'
  })
}

// 恢复读者信用
export function recoverCredit(id) {
  return request({
    url: '/work/readerinfo/recover/' + id,
    method: 'put'
  })
}
