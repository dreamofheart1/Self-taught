import request from '@/utils/request'

// 查询书架列表
export function listShelf(query) {
  return request({
    url: '/work/shelf/list',
    method: 'get',
    params: query
  })
}

// 查询书架详细
export function getShelf(id) {
  return request({
    url: '/work/shelf/' + id,
    method: 'get'
  })
}

// 新增书架
export function addShelf(data) {
  return request({
    url: '/work/shelf',
    method: 'post',
    data: data
  })
}

// 修改书架
export function updateShelf(data) {
  return request({
    url: '/work/shelf',
    method: 'put',
    data: data
  })
}

// 删除书架
export function delShelf(id) {
  return request({
    url: '/work/shelf/' + id,
    method: 'delete'
  })
}

// 获取书架选择框列表
export function optionselect() {
  return request({
    url: '/work/shelf/optionselect',
    method: 'get'
  })
}
