import request from '@/utils/request'

// 查询校区列表
export function listCampus(query) {
  return request({
    url: '/work/campus/list',
    method: 'get',
    params: query
  })
}

// 查询校区详细
export function getCampus(id) {
  return request({
    url: '/work/campus/' + id,
    method: 'get'
  })
}

// 新增校区
export function addCampus(data) {
  return request({
    url: '/work/campus',
    method: 'post',
    data: data
  })
}

// 修改校区
export function updateCampus(data) {
  return request({
    url: '/work/campus',
    method: 'put',
    data: data
  })
}

// 删除校区
export function delCampus(id) {
  return request({
    url: '/work/campus/' + id,
    method: 'delete'
  })
}

// 获取校区选择框列表
export function optionselect() {
  return request({
    url: '/work/campus/optionselect',
    method: 'get'
  })
}

