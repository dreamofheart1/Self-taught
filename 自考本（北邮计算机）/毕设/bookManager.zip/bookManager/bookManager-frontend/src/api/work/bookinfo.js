import request from '@/utils/request'

// 查询图书列表
export function listBookinfo(query) {
  return request({
    url: '/work/bookinfo/list',
    method: 'get',
    params: query
  })
}

// 查询图书详细
export function getBookinfo(id) {
  return request({
    url: '/work/bookinfo/' + id,
    method: 'get'
  })
}

// 新增图书
export function addBookinfo(data) {
  return request({
    url: '/work/bookinfo',
    method: 'post',
    data: data
  })
}

// 修改图书
export function updateBookinfo(data) {
  return request({
    url: '/work/bookinfo',
    method: 'put',
    data: data
  })
}
// 修改状态
export function changeStatus(data) {
  return request({
    url: '/work/bookinfo/changeStatus',
    method: 'put',
    data: data
  })
}

// 申请借阅图书
export function borrow(data) {
  return request({
    url: '/work/bookinfo/borrow',
    method: 'put',
    data: data
  })
}

// 删除图书
export function delBookinfo(id) {
  return request({
    url: '/work/bookinfo/' + id,
    method: 'delete'
  })
}
