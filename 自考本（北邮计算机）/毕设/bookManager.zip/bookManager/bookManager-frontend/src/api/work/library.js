import request from '@/utils/request'

// 查询图书馆列表
export function listLibrary(query) {
  return request({
    url: '/work/library/list',
    method: 'get',
    params: query
  })
}

// 查询图书馆详细
export function getLibrary(id) {
  return request({
    url: '/work/library/' + id,
    method: 'get'
  })
}

// 新增图书馆
export function addLibrary(data) {
  return request({
    url: '/work/library',
    method: 'post',
    data: data
  })
}

// 修改图书馆
export function updateLibrary(data) {
  return request({
    url: '/work/library',
    method: 'put',
    data: data
  })
}

// 删除图书馆
export function delLibrary(id) {
  return request({
    url: '/work/library/' + id,
    method: 'delete'
  })
}

// 获取图书馆选择框列表
export function optionselect() {
  return request({
    url: '/work/library/optionselect',
    method: 'get'
  })
}
