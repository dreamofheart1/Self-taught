import request from '@/utils/request'

// 查询层架列表
export function listLayer(query) {
  return request({
    url: '/work/layer/list',
    method: 'get',
    params: query
  })
}

// 查询层架详细
export function getLayer(id) {
  return request({
    url: '/work/layer/' + id,
    method: 'get'
  })
}

// 新增层架
export function addLayer(data) {
  return request({
    url: '/work/layer',
    method: 'post',
    data: data
  })
}

// 修改层架
export function updateLayer(data) {
  return request({
    url: '/work/layer',
    method: 'put',
    data: data
  })
}

// 删除层架
export function delLayer(id) {
  return request({
    url: '/work/layer/' + id,
    method: 'delete'
  })
}

// 获取层架选择框列表
export function optionselect() {
  return request({
    url: '/work/layer/optionselect',
    method: 'get'
  })
}
