import request from '@/utils/request'

// 查询借阅列表
export function listBorrow(query) {
  return request({
    url: '/work/borrow/list',
    method: 'get',
    params: query
  })
}

// 查询借阅详细
export function getBorrow(id) {
  return request({
    url: '/work/borrow/' + id,
    method: 'get'
  })
}

// 新增借阅
export function addBorrow(data) {
  return request({
    url: '/work/borrow',
    method: 'post',
    data: data
  })
}

// 修改借阅
export function updateBorrow(data) {
  return request({
    url: '/work/borrow',
    method: 'put',
    data: data
  })
}

// 删除借阅
export function delBorrow(id) {
  return request({
    url: '/work/borrow/' + id,
    method: 'delete'
  })
}

// 申请
export function applyBorrow(data) {
  return request({
    url: '/work/borrow/apply',
    method: 'put',
    data: data
  })
}

// 审核
export function checkBorrow(data) {
  return request({
    url: '/work/borrow/check',
    method: 'put',
    data: data
  })
}

// 驳回
export function rejectBorrow(data) {
  return request({
    url: '/work/borrow/reject',
    method: 'put',
    data: data
  })
}
