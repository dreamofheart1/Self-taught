import request from '@/utils/request'

// 查询图书室列表
export function listRoom(query) {
  return request({
    url: '/work/room/list',
    method: 'get',
    params: query
  })
}

// 查询图书室详细
export function getRoom(id) {
  return request({
    url: '/work/room/' + id,
    method: 'get'
  })
}

// 新增图书室
export function addRoom(data) {
  return request({
    url: '/work/room',
    method: 'post',
    data: data
  })
}

// 修改图书室
export function updateRoom(data) {
  return request({
    url: '/work/room',
    method: 'put',
    data: data
  })
}

// 删除图书室
export function delRoom(id) {
  return request({
    url: '/work/room/' + id,
    method: 'delete'
  })
}

// 获取图书室选择框列表
export function optionselect() {
  return request({
    url: '/work/room/optionselect',
    method: 'get'
  })
}
