package com.ruoyi.project.work.mapper;

import java.util.List;
import com.ruoyi.project.work.domain.Borrow;

/**
 * 借阅Mapper接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface BorrowMapper
{
    /**
     * 查询借阅
     *
     * @param id 借阅主键
     * @return 借阅
     */
    public Borrow selectBorrowById(String id);

    /**
     * 查询借阅列表
     *
     * @param borrow 借阅
     * @return 借阅集合
     */
    public List<Borrow> selectBorrowList(Borrow borrow);

    public List<Borrow> selectOutFinishdateList(Borrow borrow);

    /**
     * 新增借阅
     *
     * @param borrow 借阅
     * @return 结果
     */
    public int insertBorrow(Borrow borrow);

    /**
     * 修改借阅
     *
     * @param borrow 借阅
     * @return 结果
     */
    public int updateBorrow(Borrow borrow);

    /**
     * 删除借阅
     *
     * @param id 借阅主键
     * @return 结果
     */
    public int deleteBorrowById(String id);

    /**
     * 批量删除借阅
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteBorrowByIds(String[] ids);
}
