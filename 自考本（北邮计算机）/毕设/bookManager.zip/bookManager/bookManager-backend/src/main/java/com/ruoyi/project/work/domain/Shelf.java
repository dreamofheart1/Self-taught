package com.ruoyi.project.work.domain;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 书架对象 t_shelf
 *
 * @author dream
 * @date 2023-07-05
 */
public class Shelf extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private String id;

    /** 图书室id */
    @Excel(name = "图书室id")
    private String roomid;

    /** 图书室名称 */
    private String roomname;

    /** 架标代码 */
    @Excel(name = "架标代码")
    private String code;

    /** 架标名称 */
    @Excel(name = "架标名称")
    private String name;

    /** 排序 */
    @Excel(name = "排序")
    private Long orderid;

    /** 更新时间 */
    private Date realtime;

    /** 创建时间 */
    private String createtime;

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }
    public void setRoomid(String roomid)
    {
        this.roomid = roomid;
    }

    public String getRoomid()
    {
        return roomid;
    }

    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getCode()
    {
        return code;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
    public void setOrderid(Long orderid)
    {
        this.orderid = orderid;
    }

    public Long getOrderid()
    {
        return orderid;
    }

    public void setRealtime(Date realtime)
    {
        this.realtime = realtime;
    }

    public Date getRealtime()
    {
        return realtime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("roomid", getRoomid())
            .append("code", getCode())
            .append("name", getName())
            .append("orderid", getOrderid())
            .append("createtime", getCreatetime())
            .append("realtime", getRealtime())
            .toString();
    }
}
