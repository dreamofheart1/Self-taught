package com.ruoyi.project.work.domain;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 层架对象 t_layer
 *
 * @author dream
 * @date 2023-07-05
 */
public class Layer extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private String id;

    /** 架标uuid */
    @Excel(name = "架标uuid")
    private String shelfid;

    /** 架标名称 */
    private String shelfname;

    /** 层标代码 */
    @Excel(name = "层标代码")
    private String code;

    /** 层标名称 */
    @Excel(name = "层标名称")
    private String name;

    /** 排序 */
    @Excel(name = "排序")
    private Long orderid;

    /** 位置名称，格式000.00.0 */
    @Excel(name = "位置名称，格式000.00.0")
    private String location;

    /** 更新时间 */
    private Date realtime;

    /** 创建时间 */
    private String createtime;

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }
    public void setShelfid(String shelfid)
    {
        this.shelfid = shelfid;
    }

    public String getShelfid()
    {
        return shelfid;
    }

    public String getShelfname() {
        return shelfname;
    }

    public void setShelfname(String shelfname) {
        this.shelfname = shelfname;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getCode()
    {
        return code;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
    public void setOrderid(Long orderid)
    {
        this.orderid = orderid;
    }

    public Long getOrderid()
    {
        return orderid;
    }
    public void setLocation(String location)
    {
        this.location = location;
    }

    public String getLocation()
    {
        return location;
    }
    public void setRealtime(Date realtime)
    {
        this.realtime = realtime;
    }

    public Date getRealtime()
    {
        return realtime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("shelfid", getShelfid())
            .append("code", getCode())
            .append("name", getName())
            .append("orderid", getOrderid())
            .append("location", getLocation())
            .append("createtime", getCreatetime())
            .append("realtime", getRealtime())
            .toString();
    }
}
