package com.ruoyi.project.work.domain;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 图书对象 t_bookinfo
 *
 * @author dream
 * @date 2023-07-05
 */
public class Bookinfo extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /* ids */
    private String[] ids;

    /** id */
    private String id;

    /** 层标id */
    private String layerid;

    /** 层标名称 */
    private String layername;

    /** 条码号 */
    @Excel(name = "条码号")
    private String barcode;

    /** 题名 */
    @Excel(name = "题名")
    private String title;

    /** 作者 */
    @Excel(name = "作者")
    private String author;

    /** 出版社 */
    @Excel(name = "出版社")
    private String press;

    /** 馆藏位置 */
    @Excel(name = "馆藏位置")
    private String location;

    /** 馆藏位置代码 */
    @Excel(name = "馆藏位置代码")
    private String locationCode;

    /** 索书号 */
    @Excel(name = "索书号")
    private String callnum;

    /** 价格 */
    @Excel(name = "价格")
    private String price;

    /** 借阅状态 0在馆，1在借 */
    @Excel(name = "借阅状态 0在馆，1在借")
    private String borrowstate;

    /** 在架状态 0上架，1下架 */
    @Excel(name = "在架状态 0上架，1下架")
    private String bookstatus;


    /** 操作人员 */
    private String operators;

    /** 更新时间 */
    private Date realtime;

    /** 创建时间 */
    private String createtime;

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }


    public String[] getIds() {
        return ids;
    }

    public void setIds(String[] ids) {
        this.ids = ids;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }
    public void setLayerid(String layerid)
    {
        this.layerid = layerid;
    }

    public String getLayerid()
    {
        return layerid;
    }

    public String getLayername() {
        return layername;
    }

    public void setLayername(String layername) {
        this.layername = layername;
    }

    public void setBarcode(String barcode)
    {
        this.barcode = barcode;
    }

    public String getBarcode()
    {
        return barcode;
    }
    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getTitle()
    {
        return title;
    }
    public void setAuthor(String author)
    {
        this.author = author;
    }

    public String getAuthor()
    {
        return author;
    }
    public void setPress(String press)
    {
        this.press = press;
    }

    public String getPress()
    {
        return press;
    }
    public void setLocation(String location)
    {
        this.location = location;
    }

    public String getLocation()
    {
        return location;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public void setCallnum(String callnum)
    {
        this.callnum = callnum;
    }

    public String getCallnum()
    {
        return callnum;
    }
    public void setPrice(String price)
    {
        this.price = price;
    }

    public String getPrice()
    {
        return price;
    }
    public void setBorrowstate(String borrowstate)
    {
        this.borrowstate = borrowstate;
    }

    public String getBorrowstate()
    {
        return borrowstate;
    }
    public void setBookstatus(String bookstatus)
    {
        this.bookstatus = bookstatus;
    }

    public String getBookstatus()
    {
        return bookstatus;
    }
    public void setOperators(String operators)
    {
        this.operators = operators;
    }

    public String getOperators()
    {
        return operators;
    }
    public void setRealtime(Date realtime)
    {
        this.realtime = realtime;
    }

    public Date getRealtime()
    {
        return realtime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("layerid", getLayerid())
                .append("barcode", getBarcode())
                .append("title", getTitle())
                .append("author", getAuthor())
                .append("press", getPress())
                .append("location", getLocation())
                .append("callnum", getCallnum())
                .append("price", getPrice())
                .append("borrowstate", getBorrowstate())
                .append("bookstatus", getBookstatus())
                .append("operators", getOperators())
                .append("createtime", getCreatetime())
                .append("realtime", getRealtime())
                .toString();
    }
}
