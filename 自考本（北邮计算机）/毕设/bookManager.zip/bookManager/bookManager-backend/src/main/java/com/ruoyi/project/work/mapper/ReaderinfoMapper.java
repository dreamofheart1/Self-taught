package com.ruoyi.project.work.mapper;

import java.util.List;
import com.ruoyi.project.work.domain.Readerinfo;

/**
 * 读者Mapper接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface ReaderinfoMapper
{
    /**
     * 查询读者
     *
     * @param id 读者主键
     * @return 读者
     */
    public Readerinfo selectReaderinfoById(String id);

    /**
     * 查询读者通过userid
     *
     * @param  userid
     * @return 读者
     */
    public Readerinfo selectReaderinfoByUserid(String userid);

    /**
     * 查询读者列表
     *
     * @param readerinfo 读者
     * @return 读者集合
     */
    public List<Readerinfo> selectReaderinfoList(Readerinfo readerinfo);


    /**
     * 新增读者
     *
     * @param readerinfo 读者
     * @return 结果
     */
    public int insertReaderinfo(Readerinfo readerinfo);

    /**
     * 修改读者
     *
     * @param readerinfo 读者
     * @return 结果
     */
    public int updateReaderinfo(Readerinfo readerinfo);

    /**
     * 删除读者
     *
     * @param id 读者主键
     * @return 结果
     */
    public int deleteReaderinfoById(String id);

    /**
     * 批量删除读者
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteReaderinfoByIds(String[] ids);
}
