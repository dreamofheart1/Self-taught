package com.ruoyi.project.work.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 借阅对象 t_borrow
 *
 * @author dream
 * @date 2023-07-05
 */
public class Borrow extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private String id;

    /** 读者id */
    @Excel(name = "读者id")
    private String readerid;

    /** 图书id */
    @Excel(name = "图书id")
    private String bookid;

    /** 图书名称 */
    @Excel(name = "图书名称")
    private String bookname;

    /** 读者名称 */
    @Excel(name = "读者名称")
    private String readername;

    /* barcode */
    @Excel(name = "barcode")
    private String barcode;

    /** 借阅开始日期 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "借阅开始日期", width = 30, dateFormat = "yyyy-MM-dd")
    private Date startdate;

    /** 借阅结束日期 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "借阅结束日期", width = 30, dateFormat = "yyyy-MM-dd")
    private Date finishdate;

    /** 续借临时结束日期 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date tempfinishdate;


    /** 借阅状态 */
    @Excel(name = "借阅状态")
    private String state;

    /** 是否为读者 */
    private boolean readerFlag=false;

    /** 更新时间 */
    private Date realtime;

    /** 创建时间 */
    private String createtime;

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }
    public void setReaderid(String readerid)
    {
        this.readerid = readerid;
    }

    public String getReaderid()
    {
        return readerid;
    }
    public void setBookid(String bookid)
    {
        this.bookid = bookid;
    }

    public String getBookid()
    {
        return bookid;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public String getReadername() {
        return readername;
    }

    public void setReadername(String readername) {
        this.readername = readername;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public void setStartdate(Date startdate)
    {
        this.startdate = startdate;
    }

    public Date getStartdate()
    {
        return startdate;
    }
    public void setFinishdate(Date finishdate)
    {
        this.finishdate = finishdate;
    }

    public Date getFinishdate()
    {
        return finishdate;
    }

    public Date getTempfinishdate() {
        return tempfinishdate;
    }

    public void setTempfinishdate(Date tempfinishdate) {
        this.tempfinishdate = tempfinishdate;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    public String getState()
    {
        return state;
    }

    public boolean isReaderFlag() {
        return readerFlag;
    }

    public void setReaderFlag(boolean readerFlag) {
        this.readerFlag = readerFlag;
    }

    public void setRealtime(Date realtime)
    {
        this.realtime = realtime;
    }

    public Date getRealtime()
    {
        return realtime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("readerid", getReaderid())
            .append("bookid", getBookid())
            .append("startdate", getStartdate())
            .append("finishdate", getFinishdate())
            .append("state", getState())
            .append("createtime", getCreatetime())
            .append("realtime", getRealtime())
            .toString();
    }
}
