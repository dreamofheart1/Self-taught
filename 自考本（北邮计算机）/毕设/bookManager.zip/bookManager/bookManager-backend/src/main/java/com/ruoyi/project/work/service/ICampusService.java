package com.ruoyi.project.work.service;

import java.util.List;
import com.ruoyi.project.work.domain.Campus;

/**
 * 校区Service接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface ICampusService
{
    /**
     * 查询校区
     *
     * @param id 校区主键
     * @return 校区
     */
    public Campus selectCampusById(String id);

    /**
     * 查询校区列表
     *
     * @param campus 校区
     * @return 校区集合
     */
    public List<Campus> selectCampusList(Campus campus);

    /**
     * 新增校区
     *
     * @param campus 校区
     * @return 结果
     */
    public int insertCampus(Campus campus);

    /**
     * 修改校区
     *
     * @param campus 校区
     * @return 结果
     */
    public int updateCampus(Campus campus);

    /**
     * 批量删除校区
     *
     * @param ids 需要删除的校区主键集合
     * @return 结果
     */
    public int deleteCampusByIds(String[] ids);

    /**
     * 删除校区信息
     *
     * @param id 校区主键
     * @return 结果
     */
    public int deleteCampusById(String id);
}
