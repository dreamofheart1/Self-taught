package com.ruoyi.project.work.service.impl;

import java.util.List;

import com.ruoyi.common.utils.uuid.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.work.mapper.ShelfMapper;
import com.ruoyi.project.work.domain.Shelf;
import com.ruoyi.project.work.service.IShelfService;

/**
 * 书架Service业务层处理
 *
 * @author dream
 * @date 2023-07-05
 */
@Service
public class ShelfServiceImpl implements IShelfService
{
    @Autowired
    private ShelfMapper shelfMapper;

    /**
     * 查询书架
     *
     * @param id 书架主键
     * @return 书架
     */
    @Override
    public Shelf selectShelfById(String id)
    {
        return shelfMapper.selectShelfById(id);
    }

    /**
     * 查询书架列表
     *
     * @param shelf 书架
     * @return 书架
     */
    @Override
    public List<Shelf> selectShelfList(Shelf shelf)
    {
        return shelfMapper.selectShelfList(shelf);
    }

    /**
     * 新增书架
     *
     * @param shelf 书架
     * @return 结果
     */
    @Override
    public int insertShelf(Shelf shelf)
    {
        shelf.setId(UUID.fastUUID().toString(true));
        return shelfMapper.insertShelf(shelf);
    }

    /**
     * 修改书架
     *
     * @param shelf 书架
     * @return 结果
     */
    @Override
    public int updateShelf(Shelf shelf)
    {
        return shelfMapper.updateShelf(shelf);
    }

    /**
     * 批量删除书架
     *
     * @param ids 需要删除的书架主键
     * @return 结果
     */
    @Override
    public int deleteShelfByIds(String[] ids)
    {
        return shelfMapper.deleteShelfByIds(ids);
    }

    /**
     * 删除书架信息
     *
     * @param id 书架主键
     * @return 结果
     */
    @Override
    public int deleteShelfById(String id)
    {
        return shelfMapper.deleteShelfById(id);
    }
}
