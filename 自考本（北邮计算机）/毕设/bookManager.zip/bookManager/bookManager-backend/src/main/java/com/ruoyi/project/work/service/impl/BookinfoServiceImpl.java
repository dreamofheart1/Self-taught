package com.ruoyi.project.work.service.impl;

import java.util.List;

import com.ruoyi.common.utils.uuid.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.work.mapper.BookinfoMapper;
import com.ruoyi.project.work.domain.Bookinfo;
import com.ruoyi.project.work.service.IBookinfoService;

/**
 * 图书Service业务层处理
 *
 * @author dream
 * @date 2023-07-05
 */
@Service
public class BookinfoServiceImpl implements IBookinfoService
{
    @Autowired
    private BookinfoMapper bookinfoMapper;

    /**
     * 查询图书
     *
     * @param id 图书主键
     * @return 图书
     */
    @Override
    public Bookinfo selectBookinfoById(String id)
    {
        return bookinfoMapper.selectBookinfoById(id);
    }

    /**
     * 查询图书列表
     *
     * @param bookinfo 图书
     * @return 图书
     */
    @Override
    public List<Bookinfo> selectBookinfoList(Bookinfo bookinfo)
    {
        return bookinfoMapper.selectBookinfoList(bookinfo);
    }

    /**
     * 新增图书
     *
     * @param bookinfo 图书
     * @return 结果
     */
    @Override
    public int insertBookinfo(Bookinfo bookinfo)
    {
        bookinfo.setId(UUID.fastUUID().toString(true));
        return bookinfoMapper.insertBookinfo(bookinfo);
    }

    /**
     * 修改图书
     *
     * @param bookinfo 图书
     * @return 结果
     */
    @Override
    public int updateBookinfo(Bookinfo bookinfo)
    {
        return bookinfoMapper.updateBookinfo(bookinfo);
    }

    /**
     * 批量修改图书状态
     *
     * @param bookinfo 图书
     * @return 结果
     */
    @Override
    public int updateBookinfoStatus(Bookinfo bookinfo)
    {
        return bookinfoMapper.updateBookinfoStatus(bookinfo);
    }

    /**
     * 批量删除图书
     *
     * @param ids 需要删除的图书主键
     * @return 结果
     */
    @Override
    public int deleteBookinfoByIds(String[] ids)
    {
        return bookinfoMapper.deleteBookinfoByIds(ids);
    }

    /**
     * 删除图书信息
     *
     * @param id 图书主键
     * @return 结果
     */
    @Override
    public int deleteBookinfoById(String id)
    {
        return bookinfoMapper.deleteBookinfoById(id);
    }
}
