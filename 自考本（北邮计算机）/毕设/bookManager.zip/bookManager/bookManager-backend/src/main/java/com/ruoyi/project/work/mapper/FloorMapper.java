package com.ruoyi.project.work.mapper;

import java.util.List;
import com.ruoyi.project.work.domain.Floor;

/**
 * 楼层Mapper接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface FloorMapper
{
    /**
     * 查询楼层
     *
     * @param id 楼层主键
     * @return 楼层
     */
    public Floor selectFloorById(String id);

    /**
     * 查询楼层列表
     *
     * @param floor 楼层
     * @return 楼层集合
     */
    public List<Floor> selectFloorList(Floor floor);

    /**
     * 新增楼层
     *
     * @param floor 楼层
     * @return 结果
     */
    public int insertFloor(Floor floor);

    /**
     * 修改楼层
     *
     * @param floor 楼层
     * @return 结果
     */
    public int updateFloor(Floor floor);

    /**
     * 删除楼层
     *
     * @param id 楼层主键
     * @return 结果
     */
    public int deleteFloorById(String id);

    /**
     * 批量删除楼层
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFloorByIds(String[] ids);
}
