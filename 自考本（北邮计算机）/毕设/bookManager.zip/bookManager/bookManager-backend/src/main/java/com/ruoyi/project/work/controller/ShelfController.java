package com.ruoyi.project.work.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.enums.BusinessType;
import com.ruoyi.project.work.domain.Shelf;
import com.ruoyi.project.work.service.IShelfService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.web.page.TableDataInfo;

/**
 * 书架Controller
 *
 * @author dream
 * @date 2023-07-05
 */
@RestController
@RequestMapping("/work/shelf")
public class ShelfController extends BaseController
{
    @Autowired
    private IShelfService shelfService;

    /**
     * 查询书架列表
     */
    @PreAuthorize("@ss.hasPermi('work:shelf:list')")
    @GetMapping("/list")
    public TableDataInfo list(Shelf shelf)
    {
        startPage();
        List<Shelf> list = shelfService.selectShelfList(shelf);
        return getDataTable(list);
    }

    /**
     * 导出书架列表
     */
    @PreAuthorize("@ss.hasPermi('work:shelf:export')")
    @Log(title = "书架", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Shelf shelf)
    {
        List<Shelf> list = shelfService.selectShelfList(shelf);
        ExcelUtil<Shelf> util = new ExcelUtil<Shelf>(Shelf.class);
        util.exportExcel(response, list, "书架数据");
    }

    /**
     * 获取书架详细信息
     */
    @PreAuthorize("@ss.hasPermi('work:shelf:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(shelfService.selectShelfById(id));
    }

    /**
     * 新增书架
     */
    @PreAuthorize("@ss.hasPermi('work:shelf:add')")
    @Log(title = "书架", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Shelf shelf)
    {
        return toAjax(shelfService.insertShelf(shelf));
    }

    /**
     * 修改书架
     */
    @PreAuthorize("@ss.hasPermi('work:shelf:edit')")
    @Log(title = "书架", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Shelf shelf)
    {
        return toAjax(shelfService.updateShelf(shelf));
    }

    /**
     * 删除书架
     */
    @PreAuthorize("@ss.hasPermi('work:shelf:remove')")
    @Log(title = "书架", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(shelfService.deleteShelfByIds(ids));
    }

    @GetMapping("/optionselect")
    public AjaxResult optionselect()
    {
        List<Shelf> list = shelfService.selectShelfList(null);
        return success(list);
    }
}
