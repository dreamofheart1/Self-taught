package com.ruoyi.project.work.service;

import java.util.List;
import com.ruoyi.project.work.domain.Layer;

/**
 * 层架Service接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface ILayerService
{
    /**
     * 查询层架
     *
     * @param id 层架主键
     * @return 层架
     */
    public Layer selectLayerById(String id);

    /**
     * 查询层架列表
     *
     * @param layer 层架
     * @return 层架集合
     */
    public List<Layer> selectLayerList(Layer layer);

    /**
     * 新增层架
     *
     * @param layer 层架
     * @return 结果
     */
    public int insertLayer(Layer layer);

    /**
     * 修改层架
     *
     * @param layer 层架
     * @return 结果
     */
    public int updateLayer(Layer layer);

    /**
     * 批量删除层架
     *
     * @param ids 需要删除的层架主键集合
     * @return 结果
     */
    public int deleteLayerByIds(String[] ids);

    /**
     * 删除层架信息
     *
     * @param id 层架主键
     * @return 结果
     */
    public int deleteLayerById(String id);
}
