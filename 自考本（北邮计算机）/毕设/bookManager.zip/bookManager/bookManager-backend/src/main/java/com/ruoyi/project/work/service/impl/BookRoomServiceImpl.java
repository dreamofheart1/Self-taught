package com.ruoyi.project.work.service.impl;

import java.util.List;

import com.ruoyi.common.utils.uuid.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.work.mapper.BookRoomMapper;
import com.ruoyi.project.work.domain.BookRoom;
import com.ruoyi.project.work.service.IBookRoomService;

/**
 * 图书室Service业务层处理
 *
 * @author dream
 * @date 2023-07-05
 */
@Service
public class BookRoomServiceImpl implements IBookRoomService
{
    @Autowired
    private BookRoomMapper bookRoomMapper;

    /**
     * 查询图书室
     *
     * @param id 图书室主键
     * @return 图书室
     */
    @Override
    public BookRoom selectBookRoomById(String id)
    {
        return bookRoomMapper.selectBookRoomById(id);
    }

    /**
     * 查询图书室列表
     *
     * @param bookRoom 图书室
     * @return 图书室
     */
    @Override
    public List<BookRoom> selectBookRoomList(BookRoom bookRoom)
    {
        return bookRoomMapper.selectBookRoomList(bookRoom);
    }

    /**
     * 新增图书室
     *
     * @param bookRoom 图书室
     * @return 结果
     */
    @Override
    public int insertBookRoom(BookRoom bookRoom)
    {
        bookRoom.setId(UUID.fastUUID().toString(true));
        return bookRoomMapper.insertBookRoom(bookRoom);
    }

    /**
     * 修改图书室
     *
     * @param bookRoom 图书室
     * @return 结果
     */
    @Override
    public int updateBookRoom(BookRoom bookRoom)
    {
        return bookRoomMapper.updateBookRoom(bookRoom);
    }

    /**
     * 批量删除图书室
     *
     * @param ids 需要删除的图书室主键
     * @return 结果
     */
    @Override
    public int deleteBookRoomByIds(String[] ids)
    {
        return bookRoomMapper.deleteBookRoomByIds(ids);
    }

    /**
     * 删除图书室信息
     *
     * @param id 图书室主键
     * @return 结果
     */
    @Override
    public int deleteBookRoomById(String id)
    {
        return bookRoomMapper.deleteBookRoomById(id);
    }
}
