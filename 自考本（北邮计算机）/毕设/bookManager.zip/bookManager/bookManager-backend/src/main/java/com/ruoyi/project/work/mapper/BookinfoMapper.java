package com.ruoyi.project.work.mapper;

import java.util.List;
import com.ruoyi.project.work.domain.Bookinfo;

/**
 * 图书Mapper接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface BookinfoMapper
{
    /**
     * 查询图书
     *
     * @param id 图书主键
     * @return 图书
     */
    public Bookinfo selectBookinfoById(String id);

    /**
     * 查询图书列表
     *
     * @param bookinfo 图书
     * @return 图书集合
     */
    public List<Bookinfo> selectBookinfoList(Bookinfo bookinfo);

    /**
     * 新增图书
     *
     * @param bookinfo 图书
     * @return 结果
     */
    public int insertBookinfo(Bookinfo bookinfo);

    /**
     * 修改图书
     *
     * @param bookinfo 图书
     * @return 结果
     */
    public int updateBookinfo(Bookinfo bookinfo);

    /**
     * 修改图书状态
     *
     * @param bookinfo 图书
     * @return 结果
     */
    public int updateBookinfoStatus(Bookinfo bookinfo);

    /**
     * 删除图书
     *
     * @param id 图书主键
     * @return 结果
     */
    public int deleteBookinfoById(String id);

    /**
     * 批量删除图书
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteBookinfoByIds(String[] ids);
}
