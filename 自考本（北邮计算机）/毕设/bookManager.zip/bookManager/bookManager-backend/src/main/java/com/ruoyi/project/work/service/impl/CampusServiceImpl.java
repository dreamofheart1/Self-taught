package com.ruoyi.project.work.service.impl;

import java.util.List;

import com.ruoyi.common.utils.uuid.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.work.mapper.CampusMapper;
import com.ruoyi.project.work.domain.Campus;
import com.ruoyi.project.work.service.ICampusService;

/**
 * 校区Service业务层处理
 *
 * @author dream
 * @date 2023-07-05
 */
@Service
public class CampusServiceImpl implements ICampusService
{
    @Autowired
    private CampusMapper campusMapper;

    /**
     * 查询校区
     *
     * @param id 校区主键
     * @return 校区
     */
    @Override
    public Campus selectCampusById(String id)
    {
        return campusMapper.selectCampusById(id);
    }

    /**
     * 查询校区列表
     *
     * @param campus 校区
     * @return 校区
     */
    @Override
    public List<Campus> selectCampusList(Campus campus)
    {
        return campusMapper.selectCampusList(campus);
    }

    /**
     * 新增校区
     *
     * @param campus 校区
     * @return 结果
     */
    @Override
    public int insertCampus(Campus campus)
    {
        campus.setId(UUID.fastUUID().toString(true));
        return campusMapper.insertCampus(campus);
    }

    /**
     * 修改校区
     *
     * @param campus 校区
     * @return 结果
     */
    @Override
    public int updateCampus(Campus campus)
    {
        return campusMapper.updateCampus(campus);
    }

    /**
     * 批量删除校区
     *
     * @param ids 需要删除的校区主键
     * @return 结果
     */
    @Override
    public int deleteCampusByIds(String[] ids)
    {
        return campusMapper.deleteCampusByIds(ids);
    }

    /**
     * 删除校区信息
     *
     * @param id 校区主键
     * @return 结果
     */
    @Override
    public int deleteCampusById(String id)
    {
        return campusMapper.deleteCampusById(id);
    }
}
