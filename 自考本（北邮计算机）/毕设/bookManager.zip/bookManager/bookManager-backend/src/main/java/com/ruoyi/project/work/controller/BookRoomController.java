package com.ruoyi.project.work.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.enums.BusinessType;
import com.ruoyi.project.work.domain.BookRoom;
import com.ruoyi.project.work.service.IBookRoomService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.web.page.TableDataInfo;

/**
 * 图书室Controller
 *
 * @author dream
 * @date 2023-07-05
 */
@RestController
@RequestMapping("/work/room")
public class BookRoomController extends BaseController
{
    @Autowired
    private IBookRoomService bookRoomService;

    /**
     * 查询图书室列表
     */
    @PreAuthorize("@ss.hasPermi('work:room:list')")
    @GetMapping("/list")
    public TableDataInfo list(BookRoom bookRoom)
    {
        startPage();
        List<BookRoom> list = bookRoomService.selectBookRoomList(bookRoom);
        return getDataTable(list);
    }

    /**
     * 导出图书室列表
     */
    @PreAuthorize("@ss.hasPermi('work:room:export')")
    @Log(title = "图书室", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, BookRoom bookRoom)
    {
        List<BookRoom> list = bookRoomService.selectBookRoomList(bookRoom);
        ExcelUtil<BookRoom> util = new ExcelUtil<BookRoom>(BookRoom.class);
        util.exportExcel(response, list, "图书室数据");
    }

    /**
     * 获取图书室详细信息
     */
    @PreAuthorize("@ss.hasPermi('work:room:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(bookRoomService.selectBookRoomById(id));
    }

    /**
     * 新增图书室
     */
    @PreAuthorize("@ss.hasPermi('work:room:add')")
    @Log(title = "图书室", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody BookRoom bookRoom)
    {
        return toAjax(bookRoomService.insertBookRoom(bookRoom));
    }

    /**
     * 修改图书室
     */
    @PreAuthorize("@ss.hasPermi('work:room:edit')")
    @Log(title = "图书室", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody BookRoom bookRoom)
    {
        return toAjax(bookRoomService.updateBookRoom(bookRoom));
    }

    /**
     * 删除图书室
     */
    @PreAuthorize("@ss.hasPermi('work:room:remove')")
    @Log(title = "图书室", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(bookRoomService.deleteBookRoomByIds(ids));
    }

    @GetMapping("/optionselect")
    public AjaxResult optionselect()
    {
        List<BookRoom> list = bookRoomService.selectBookRoomList(null);
        return success(list);
    }
}
