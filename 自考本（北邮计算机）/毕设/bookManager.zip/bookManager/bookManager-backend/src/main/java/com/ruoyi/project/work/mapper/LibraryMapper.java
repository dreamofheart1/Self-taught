package com.ruoyi.project.work.mapper;

import java.util.List;
import com.ruoyi.project.work.domain.Library;

/**
 * 图书馆Mapper接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface LibraryMapper
{
    /**
     * 查询图书馆
     *
     * @param id 图书馆主键
     * @return 图书馆
     */
    public Library selectLibraryById(String id);

    /**
     * 查询图书馆列表
     *
     * @param library 图书馆
     * @return 图书馆集合
     */
    public List<Library> selectLibraryList(Library library);

    /**
     * 新增图书馆
     *
     * @param library 图书馆
     * @return 结果
     */
    public int insertLibrary(Library library);

    /**
     * 修改图书馆
     *
     * @param library 图书馆
     * @return 结果
     */
    public int updateLibrary(Library library);

    /**
     * 删除图书馆
     *
     * @param id 图书馆主键
     * @return 结果
     */
    public int deleteLibraryById(String id);

    /**
     * 批量删除图书馆
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteLibraryByIds(String[] ids);
}
