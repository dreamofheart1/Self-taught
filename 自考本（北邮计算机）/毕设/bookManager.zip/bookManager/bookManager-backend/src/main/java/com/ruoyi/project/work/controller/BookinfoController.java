package com.ruoyi.project.work.controller;

import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.work.domain.Borrow;
import com.ruoyi.project.work.domain.Readerinfo;
import com.ruoyi.project.work.service.IBorrowService;
import com.ruoyi.project.work.service.IReaderinfoService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.enums.BusinessType;
import com.ruoyi.project.work.domain.Bookinfo;
import com.ruoyi.project.work.service.IBookinfoService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;

/**
 * 图书Controller
 *
 * @author dream
 * @date 2023-07-05
 */
@RestController
@RequestMapping("/work/bookinfo")
public class BookinfoController extends BaseController
{
    @Autowired
    private IBookinfoService bookinfoService;

    @Autowired
    private IReaderinfoService readerinfoService;

    @Autowired
    private IBorrowService borrowService;

    /**
     * 查询图书列表
     */
    @PreAuthorize("@ss.hasPermi('work:bookinfo:list')")
    @GetMapping("/list")
    public Object list(Bookinfo bookinfo)
    {

        Readerinfo readerinfo = readerinfoService.selectReaderinfoByUserid(getUserId().toString());

        startPage();
        List<Bookinfo> list = bookinfoService.selectBookinfoList(bookinfo);
        return this.getDataTableAjaxResult(list).put("readerinfo",readerinfo);
    }

    /**
     * 导出图书列表
     */
    @PreAuthorize("@ss.hasPermi('work:bookinfo:export')")
    @Log(title = "图书", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Bookinfo bookinfo)
    {
        List<Bookinfo> list = bookinfoService.selectBookinfoList(bookinfo);
        ExcelUtil<Bookinfo> util = new ExcelUtil<Bookinfo>(Bookinfo.class);
        util.exportExcel(response, list, "图书数据");
    }

    /**
     * 获取图书详细信息
     */
    @PreAuthorize("@ss.hasPermi('work:bookinfo:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(bookinfoService.selectBookinfoById(id));
    }

    /**
     * 新增图书
     */
    @PreAuthorize("@ss.hasPermi('work:bookinfo:add')")
    @Log(title = "图书", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Bookinfo bookinfo)
    {
        bookinfo.setBorrowstate("0");
        bookinfo.setBookstatus("0");
        return toAjax(bookinfoService.insertBookinfo(bookinfo));
    }

    /**
     * 修改图书
     */
    @PreAuthorize("@ss.hasPermi('work:bookinfo:edit')")
    @Log(title = "图书", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Bookinfo bookinfo)
    {
        return toAjax(bookinfoService.updateBookinfo(bookinfo));
    }

    /**
     * 修改图书状态
     */
    @PreAuthorize("@ss.hasAnyPermi('work:bookinfo:up,work:bookinfo:out,work:bookinfo:borrow')")
    @Log(title = "图书", businessType = BusinessType.UPDATE)
    @PutMapping("/changeStatus")
    public AjaxResult changeStatus(@RequestBody Bookinfo bookinfo)
    {
        return toAjax(bookinfoService.updateBookinfoStatus(bookinfo));
    }

    /**
     * 借阅图书
     */
    @PreAuthorize("@ss.hasPermi('work:bookinfo:borrow')")
    @Log(title = "图书", businessType = BusinessType.UPDATE)
    @PutMapping("/borrow")
    @Transactional
    public AjaxResult borrow(@RequestBody Borrow borrow)
    {
        // 判断当前用户是否有读者信息
        Readerinfo readerinfo = readerinfoService.selectReaderinfoByUserid(getUserId().toString());

        if(StringUtils.isNull(readerinfo)||StringUtils.isEmpty(readerinfo.getId())) {
            return AjaxResult.error("当前用户没有读者信息，请先完善读者信息");
        }else if ("1".equals(readerinfo.getState())){
            return AjaxResult.error("当前用户已被禁用，请联系管理员");
        }
        // 更新图书借阅状态
        Bookinfo bookinfo = new Bookinfo();
        bookinfo.setId(borrow.getBookid());
        bookinfo.setBorrowstate("1");
        bookinfoService.updateBookinfo(bookinfo);
        // 创建借阅记录
        borrow.setReaderid(readerinfo.getId());
        // 生成当前日期
        borrow.setStartdate(new Date());
        borrow.setState("0");
        AjaxResult success = AjaxResult.success(borrowService.insertBorrow(borrow));
        return success;
    }

    /**
     * 删除图书
     */
    @PreAuthorize("@ss.hasPermi('work:bookinfo:remove')")
    @Log(title = "图书", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(bookinfoService.deleteBookinfoByIds(ids));
    }
}
