package com.ruoyi.project.work.mapper;

import java.util.List;
import com.ruoyi.project.work.domain.Shelf;

/**
 * 书架Mapper接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface ShelfMapper
{
    /**
     * 查询书架
     *
     * @param id 书架主键
     * @return 书架
     */
    public Shelf selectShelfById(String id);

    /**
     * 查询书架列表
     *
     * @param shelf 书架
     * @return 书架集合
     */
    public List<Shelf> selectShelfList(Shelf shelf);

    /**
     * 新增书架
     *
     * @param shelf 书架
     * @return 结果
     */
    public int insertShelf(Shelf shelf);

    /**
     * 修改书架
     *
     * @param shelf 书架
     * @return 结果
     */
    public int updateShelf(Shelf shelf);

    /**
     * 删除书架
     *
     * @param id 书架主键
     * @return 结果
     */
    public int deleteShelfById(String id);

    /**
     * 批量删除书架
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteShelfByIds(String[] ids);
}
