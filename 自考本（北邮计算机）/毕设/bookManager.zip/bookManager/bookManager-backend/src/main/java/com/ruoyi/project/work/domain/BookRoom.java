package com.ruoyi.project.work.domain;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 图书室对象 t_book_room
 *
 * @author dream
 * @date 2023-07-05
 */
public class BookRoom extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private String id;

    /** 楼层id */
    @Excel(name = "楼层id")
    private String floorid;

    /** 楼层名称 */
    private String floorname;

    /** 代号 */
    @Excel(name = "代号")
    private String code;

    /** 馆区名称 */
    @Excel(name = "馆区名称")
    private String name;

    /** 排序 */
    @Excel(name = "排序")
    private Long orderid;

    /** 更新时间 */
    private Date realtime;

    /** 创建时间 */
    private String createtime;

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }
    public void setFloorid(String floorid)
    {
        this.floorid = floorid;
    }

    public String getFloorid()
    {
        return floorid;
    }

    public String getFloorname() {
        return floorname;
    }

    public void setFloorname(String floorname) {
        this.floorname = floorname;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getCode()
    {
        return code;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public Long getOrderid() {
        return orderid;
    }

    public void setOrderid(Long orderid) {
        this.orderid = orderid;
    }

    public void setRealtime(Date realtime)
    {
        this.realtime = realtime;
    }

    public Date getRealtime()
    {
        return realtime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("floorid", getFloorid())
            .append("code", getCode())
            .append("name", getName())
            .append("orderid", getOrderid())
            .append("createtime", getCreatetime())
            .append("realtime", getRealtime())
            .toString();
    }
}
