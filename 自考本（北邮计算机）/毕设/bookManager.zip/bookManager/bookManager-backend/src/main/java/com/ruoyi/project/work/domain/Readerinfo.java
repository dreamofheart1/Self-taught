package com.ruoyi.project.work.domain;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 读者对象 t_readerinfo
 *
 * @author dream
 * @date 2023-07-05
 */
public class Readerinfo extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private String id;

    /** 用户id */
    @Excel(name = "用户id")
    private String userid;

    /* username */
    @Excel(name = "用户名")
    private String username;

    /** 读者姓名 */
    @Excel(name = "读者姓名")
    private String name;

    /** 身份证号 */
    @Excel(name = "身份证号")
    private String idnum;

    /** 读者状态（0 正常，1 失信） */
    @Excel(name = "读者状态", readConverterExp = "0=,正=常，1,失=信")
    private String state;

    /** 更新时间 */
    private Date realtime;

    /** 创建时间 */
    private String createtime;

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }
    public void setUserid(String userid)
    {
        this.userid = userid;
    }

    public String getUserid()
    {
        return userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
    public void setIdnum(String idnum)
    {
        this.idnum = idnum;
    }

    public String getIdnum()
    {
        return idnum;
    }
    public void setState(String state)
    {
        this.state = state;
    }

    public String getState()
    {
        return state;
    }
    public void setRealtime(Date realtime)
    {
        this.realtime = realtime;
    }

    public Date getRealtime()
    {
        return realtime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("userid", getUserid())
            .append("name", getName())
            .append("idnum", getIdnum())
            .append("state", getState())
            .append("createtime", getCreatetime())
            .append("realtime", getRealtime())
            .toString();
    }
}
