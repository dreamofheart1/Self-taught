package com.ruoyi.framework.task;

import com.ruoyi.project.work.domain.Borrow;
import com.ruoyi.project.work.domain.Readerinfo;
import com.ruoyi.project.work.mapper.BorrowMapper;
import com.ruoyi.project.work.mapper.ReaderinfoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * 定时任务调度测试
 *
 * @author dream
 */
@Component("workTask")
public class WorkTask
{
    @Autowired
    private BorrowMapper borrowMapper;

    @Autowired
    private ReaderinfoMapper readerinfoMapper;

    @Transactional
    public void checkBorrowinfo()
    {
        System.out.println("执行检查借阅信息方法");
        Borrow borrow =new Borrow();
        borrow.setFinishdate(new Date());
        List<Borrow> borrows = borrowMapper.selectOutFinishdateList(borrow);

        borrows.stream().forEach(b -> {
            // 根据逾期的借阅信息，更新借阅信息
            b.setState("6");
            borrowMapper.updateBorrow(b);
            // 根据逾期的借阅信息，更新读者信息
            Readerinfo readerinfo =new Readerinfo();
            readerinfo.setId(b.getReaderid());
            readerinfo.setState("1");
            readerinfoMapper.updateReaderinfo(readerinfo);
        });

    }

}
