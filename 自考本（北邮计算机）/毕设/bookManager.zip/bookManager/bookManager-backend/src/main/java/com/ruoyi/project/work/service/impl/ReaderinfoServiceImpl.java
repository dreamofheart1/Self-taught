package com.ruoyi.project.work.service.impl;

import java.util.List;

import com.ruoyi.common.utils.uuid.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.work.mapper.ReaderinfoMapper;
import com.ruoyi.project.work.domain.Readerinfo;
import com.ruoyi.project.work.service.IReaderinfoService;

/**
 * 读者Service业务层处理
 *
 * @author dream
 * @date 2023-07-05
 */
@Service
public class ReaderinfoServiceImpl implements IReaderinfoService
{
    @Autowired
    private ReaderinfoMapper readerinfoMapper;

    /**
     * 查询读者
     *
     * @param id 读者主键
     * @return 读者
     */
    @Override
    public Readerinfo selectReaderinfoById(String id)
    {
        return readerinfoMapper.selectReaderinfoById(id);
    }

    /**
     * 查询读者通过userid
     *
     * @param  userid
     * @return 读者
     */
    @Override
    public Readerinfo selectReaderinfoByUserid(String userid)
    {
        return readerinfoMapper.selectReaderinfoByUserid(userid);
    }


    /**
     * 查询读者列表
     *
     * @param readerinfo 读者
     * @return 读者
     */
    @Override
    public List<Readerinfo> selectReaderinfoList(Readerinfo readerinfo)
    {
        return readerinfoMapper.selectReaderinfoList(readerinfo);
    }

    /**
     * 新增读者
     *
     * @param readerinfo 读者
     * @return 结果
     */
    @Override
    public int insertReaderinfo(Readerinfo readerinfo)
    {
        readerinfo.setId(UUID.fastUUID().toString(true));
        return readerinfoMapper.insertReaderinfo(readerinfo);
    }

    /**
     * 修改读者
     *
     * @param readerinfo 读者
     * @return 结果
     */
    @Override
    public int updateReaderinfo(Readerinfo readerinfo)
    {
        return readerinfoMapper.updateReaderinfo(readerinfo);
    }

    /**
     * 批量删除读者
     *
     * @param ids 需要删除的读者主键
     * @return 结果
     */
    @Override
    public int deleteReaderinfoByIds(String[] ids)
    {
        return readerinfoMapper.deleteReaderinfoByIds(ids);
    }

    /**
     * 删除读者信息
     *
     * @param id 读者主键
     * @return 结果
     */
    @Override
    public int deleteReaderinfoById(String id)
    {
        return readerinfoMapper.deleteReaderinfoById(id);
    }
}
