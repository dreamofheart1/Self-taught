package com.ruoyi.project.work.service;

import java.util.List;
import com.ruoyi.project.work.domain.BookRoom;

/**
 * 图书室Service接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface IBookRoomService
{
    /**
     * 查询图书室
     *
     * @param id 图书室主键
     * @return 图书室
     */
    public BookRoom selectBookRoomById(String id);

    /**
     * 查询图书室列表
     *
     * @param bookRoom 图书室
     * @return 图书室集合
     */
    public List<BookRoom> selectBookRoomList(BookRoom bookRoom);

    /**
     * 新增图书室
     *
     * @param bookRoom 图书室
     * @return 结果
     */
    public int insertBookRoom(BookRoom bookRoom);

    /**
     * 修改图书室
     *
     * @param bookRoom 图书室
     * @return 结果
     */
    public int updateBookRoom(BookRoom bookRoom);

    /**
     * 批量删除图书室
     *
     * @param ids 需要删除的图书室主键集合
     * @return 结果
     */
    public int deleteBookRoomByIds(String[] ids);

    /**
     * 删除图书室信息
     *
     * @param id 图书室主键
     * @return 结果
     */
    public int deleteBookRoomById(String id);
}
