package com.ruoyi.project.work.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.work.service.ICampusService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.enums.BusinessType;
import com.ruoyi.project.work.domain.Library;
import com.ruoyi.project.work.service.ILibraryService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.web.page.TableDataInfo;

/**
 * 图书馆Controller
 *
 * @author dream
 * @date 2023-07-05
 */
@RestController
@RequestMapping("/work/library")
public class LibraryController extends BaseController
{
    @Autowired
    private ILibraryService libraryService;

    @Autowired
    private ICampusService campusService;


    /**
     * 查询图书馆列表
     */
    @PreAuthorize("@ss.hasPermi('work:library:list')")
    @GetMapping("/list")
    public TableDataInfo list(Library library)
    {
        startPage();
        List<Library> list = libraryService.selectLibraryList(library);
        return getDataTable(list);
    }

    /**
     * 导出图书馆列表
     */
    @PreAuthorize("@ss.hasPermi('work:library:export')")
    @Log(title = "图书馆", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Library library)
    {
        List<Library> list = libraryService.selectLibraryList(library);
        ExcelUtil<Library> util = new ExcelUtil<Library>(Library.class);
        util.exportExcel(response, list, "图书馆数据");
    }

    /**
     * 获取图书馆详细信息
     */
    @PreAuthorize("@ss.hasPermi('work:library:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        AjaxResult ajax = AjaxResult.success();
        ajax.put("campusidOptions",campusService.selectCampusList(null));
        if (StringUtils.isNotEmpty(id)) {
            ajax.put(AjaxResult.DATA_TAG, libraryService.selectLibraryById(id));
        }
        return ajax;
    }

    /**
     * 新增图书馆
     */
    @PreAuthorize("@ss.hasPermi('work:library:add')")
    @Log(title = "图书馆", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Library library)
    {
        return toAjax(libraryService.insertLibrary(library));
    }

    /**
     * 修改图书馆
     */
    @PreAuthorize("@ss.hasPermi('work:library:edit')")
    @Log(title = "图书馆", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Library library)
    {
        return toAjax(libraryService.updateLibrary(library));
    }

    /**
     * 删除图书馆
     */
    @PreAuthorize("@ss.hasPermi('work:library:remove')")
    @Log(title = "图书馆", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(libraryService.deleteLibraryByIds(ids));
    }

    @GetMapping("/optionselect")
    public AjaxResult optionselect()
    {
        List<Library> list = libraryService.selectLibraryList(null);
        return success(list);
    }
}
