package com.ruoyi.project.work.service;

import java.util.List;
import com.ruoyi.project.work.domain.Library;

/**
 * 图书馆Service接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface ILibraryService
{
    /**
     * 查询图书馆
     *
     * @param id 图书馆主键
     * @return 图书馆
     */
    public Library selectLibraryById(String id);

    /**
     * 查询图书馆列表
     *
     * @param library 图书馆
     * @return 图书馆集合
     */
    public List<Library> selectLibraryList(Library library);

    /**
     * 新增图书馆
     *
     * @param library 图书馆
     * @return 结果
     */
    public int insertLibrary(Library library);

    /**
     * 修改图书馆
     *
     * @param library 图书馆
     * @return 结果
     */
    public int updateLibrary(Library library);

    /**
     * 批量删除图书馆
     *
     * @param ids 需要删除的图书馆主键集合
     * @return 结果
     */
    public int deleteLibraryByIds(String[] ids);

    /**
     * 删除图书馆信息
     *
     * @param id 图书馆主键
     * @return 结果
     */
    public int deleteLibraryById(String id);
}
