package com.ruoyi.project.work.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.project.work.domain.Bookinfo;
import com.ruoyi.project.work.domain.Borrow;
import com.ruoyi.project.work.service.IBookinfoService;
import com.ruoyi.project.work.service.IBorrowService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.enums.BusinessType;
import com.ruoyi.project.work.domain.Readerinfo;
import com.ruoyi.project.work.service.IReaderinfoService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.web.page.TableDataInfo;

/**
 * 读者Controller
 *
 * @author dream
 * @date 2023-07-05
 */
@RestController
@RequestMapping("/work/readerinfo")
public class ReaderinfoController extends BaseController
{
    @Autowired
    private IReaderinfoService readerinfoService;

    @Autowired
    private IBookinfoService bookinfoService;


    @Autowired
    private IBorrowService borrowService;

    /**
     * 查询读者列表
     */
    @PreAuthorize("@ss.hasPermi('work:readerinfo:list')")
    @GetMapping("/list")
    public TableDataInfo list(Readerinfo readerinfo)
    {
        startPage();
        List<Readerinfo> list = readerinfoService.selectReaderinfoList(readerinfo);
        return getDataTable(list);
    }

    /**
     * 导出读者列表
     */
    @PreAuthorize("@ss.hasPermi('work:readerinfo:export')")
    @Log(title = "读者", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Readerinfo readerinfo)
    {
        List<Readerinfo> list = readerinfoService.selectReaderinfoList(readerinfo);
        ExcelUtil<Readerinfo> util = new ExcelUtil<Readerinfo>(Readerinfo.class);
        util.exportExcel(response, list, "读者数据");
    }

    /**
     * 获取读者详细信息
     */
    @PreAuthorize("@ss.hasPermi('work:readerinfo:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(readerinfoService.selectReaderinfoById(id));
    }

    /**
     * 新增读者
     */
    @PreAuthorize("@ss.hasPermi('work:readerinfo:add')")
    @Log(title = "读者", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Readerinfo readerinfo)
    {
        // 新增读者时，信用状态为0,即正常
        readerinfo.setState("0");
        return toAjax(readerinfoService.insertReaderinfo(readerinfo));
    }

    /**
     * 修改读者
     */
    @PreAuthorize("@ss.hasPermi('work:readerinfo:edit')")
    @Log(title = "读者", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Readerinfo readerinfo)
    {
        return toAjax(readerinfoService.updateReaderinfo(readerinfo));
    }

    /**
     * 删除读者
     */
    @PreAuthorize("@ss.hasPermi('work:readerinfo:remove')")
    @Log(title = "读者", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(readerinfoService.deleteReaderinfoByIds(ids));
    }

    /**
     * 恢复读者信用
     */
    @PreAuthorize("@ss.hasPermi('work:readerinfo:recover')")
    @Log(title = "读者", businessType = BusinessType.UPDATE)
    @PutMapping("/recover/{id}")
    @Transactional
    public AjaxResult recover(@PathVariable("id") String id)
    {
        // 修改借阅状态
        Borrow borrow = new Borrow();
        borrow.setReaderid(id);
        borrow.setState("6");
        List<Borrow> borrows = borrowService.selectBorrowList(borrow);
        borrows.stream().forEach(borrow1 -> {
            // 修改借阅状态
            borrow1.setState("5");
            borrowService.updateBorrow(borrow1);
            // 修改图书状态
            Bookinfo bookinfo = new Bookinfo();
            bookinfo.setId(borrow1.getBookid());
            bookinfo.setBorrowstate("0");
            bookinfoService.updateBookinfo(bookinfo);
        });
        // 最后修改读者信用
        Readerinfo readerinfo = new Readerinfo();
        readerinfo.setId(id);
        readerinfo.setState("0");
        return toAjax(readerinfoService.updateReaderinfo(readerinfo));
    }
}
