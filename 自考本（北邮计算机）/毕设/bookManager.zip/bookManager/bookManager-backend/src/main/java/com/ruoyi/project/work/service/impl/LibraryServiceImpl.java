package com.ruoyi.project.work.service.impl;

import java.util.List;

import com.ruoyi.common.utils.uuid.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.work.mapper.LibraryMapper;
import com.ruoyi.project.work.domain.Library;
import com.ruoyi.project.work.service.ILibraryService;

/**
 * 图书馆Service业务层处理
 *
 * @author dream
 * @date 2023-07-05
 */
@Service
public class LibraryServiceImpl implements ILibraryService
{
    @Autowired
    private LibraryMapper libraryMapper;

    /**
     * 查询图书馆
     *
     * @param id 图书馆主键
     * @return 图书馆
     */
    @Override
    public Library selectLibraryById(String id)
    {
        return libraryMapper.selectLibraryById(id);
    }

    /**
     * 查询图书馆列表
     *
     * @param library 图书馆
     * @return 图书馆
     */
    @Override
    public List<Library> selectLibraryList(Library library)
    {
        return libraryMapper.selectLibraryList(library);
    }

    /**
     * 新增图书馆
     *
     * @param library 图书馆
     * @return 结果
     */
    @Override
    public int insertLibrary(Library library)
    {
        library.setId(UUID.fastUUID().toString(true));
        return libraryMapper.insertLibrary(library);
    }

    /**
     * 修改图书馆
     *
     * @param library 图书馆
     * @return 结果
     */
    @Override
    public int updateLibrary(Library library)
    {
        return libraryMapper.updateLibrary(library);
    }

    /**
     * 批量删除图书馆
     *
     * @param ids 需要删除的图书馆主键
     * @return 结果
     */
    @Override
    public int deleteLibraryByIds(String[] ids)
    {
        return libraryMapper.deleteLibraryByIds(ids);
    }

    /**
     * 删除图书馆信息
     *
     * @param id 图书馆主键
     * @return 结果
     */
    @Override
    public int deleteLibraryById(String id)
    {
        return libraryMapper.deleteLibraryById(id);
    }
}
