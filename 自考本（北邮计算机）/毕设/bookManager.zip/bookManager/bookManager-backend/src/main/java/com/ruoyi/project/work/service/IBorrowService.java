package com.ruoyi.project.work.service;

import java.util.List;
import com.ruoyi.project.work.domain.Borrow;

/**
 * 借阅Service接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface IBorrowService
{
    /**
     * 查询借阅
     *
     * @param id 借阅主键
     * @return 借阅
     */
    public Borrow selectBorrowById(String id);

    /**
     * 查询借阅列表
     *
     * @param borrow 借阅
     * @return 借阅集合
     */
    public List<Borrow> selectBorrowList(Borrow borrow);

    /**
     * 新增借阅
     *
     * @param borrow 借阅
     * @return 结果
     */
    public int insertBorrow(Borrow borrow);

    /**
     * 修改借阅
     *
     * @param borrow 借阅
     * @return 结果
     */
    public int updateBorrow(Borrow borrow);

    /**
     * 批量删除借阅
     *
     * @param ids 需要删除的借阅主键集合
     * @return 结果
     */
    public int deleteBorrowByIds(String[] ids);

    /**
     * 删除借阅信息
     *
     * @param id 借阅主键
     * @return 结果
     */
    public int deleteBorrowById(String id);
}
