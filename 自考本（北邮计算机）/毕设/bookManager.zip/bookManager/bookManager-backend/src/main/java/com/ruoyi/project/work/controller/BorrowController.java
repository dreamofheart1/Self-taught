package com.ruoyi.project.work.controller;

import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.project.work.domain.Bookinfo;
import com.ruoyi.project.work.domain.Readerinfo;
import com.ruoyi.project.work.service.IBookinfoService;
import com.ruoyi.project.work.service.IReaderinfoService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.enums.BusinessType;
import com.ruoyi.project.work.domain.Borrow;
import com.ruoyi.project.work.service.IBorrowService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.web.page.TableDataInfo;

/**
 * 借阅Controller
 *
 * @author dream
 * @date 2023-07-05
 */
@RestController
@RequestMapping("/work/borrow")
public class BorrowController extends BaseController
{
    @Autowired
    private IBorrowService borrowService;

    @Autowired
    private IBookinfoService bookinfoService;

    @Autowired
    private IReaderinfoService readerinfoService;


    /**
     * 查询借阅列表
     */
    @PreAuthorize("@ss.hasAnyPermi('work:borrow:list,work:borrowapply:list')")
    @GetMapping("/list")
    public TableDataInfo list(Borrow borrow)
    {
        if(borrow.isReaderFlag()) {
            try {
                Readerinfo readerinfo = readerinfoService.selectReaderinfoByUserid(getUserId().toString());
                borrow.setReaderid(readerinfo.getId());
            } catch (Exception e) {
                throw new RuntimeException("获取读者信息失败");
            }
        }
        startPage();
        List<Borrow> list = borrowService.selectBorrowList(borrow);
        return getDataTable(list);
    }

    /**
     * 导出借阅列表
     */
    @PreAuthorize("@ss.hasPermi('work:borrow:export')")
    @Log(title = "借阅", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Borrow borrow)
    {
        List<Borrow> list = borrowService.selectBorrowList(borrow);
        ExcelUtil<Borrow> util = new ExcelUtil<Borrow>(Borrow.class);
        util.exportExcel(response, list, "借阅数据");
    }

    /**
     * 获取借阅详细信息
     */
    @PreAuthorize("@ss.hasPermi('work:borrow:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(borrowService.selectBorrowById(id));
    }

    /**
     * 新增借阅
     */
    @PreAuthorize("@ss.hasPermi('work:borrow:add')")
    @Log(title = "借阅", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Borrow borrow)
    {
        return toAjax(borrowService.insertBorrow(borrow));
    }

    /**
     * 修改借阅
     */
    @PreAuthorize("@ss.hasPermi('work:borrow:edit')")
    @Log(title = "借阅", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Borrow borrow)
    {
        return toAjax(borrowService.updateBorrow(borrow));
    }

    /**
     * 删除借阅
     */
    @PreAuthorize("@ss.hasPermi('work:borrow:remove')")
    @Log(title = "借阅", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(borrowService.deleteBorrowByIds(ids));
    }

    /**
     * 申请
     */
    @PreAuthorize("@ss.hasPermi('work:borrowapply:apply')")
    @Log(title = "借阅", businessType = BusinessType.UPDATE)
    @PutMapping("/apply")
    public AjaxResult apply(@RequestBody Borrow borrow)
    {
        String id = borrow.getId();
        String state = borrow.getState();
        Date finishdate = borrow.getFinishdate();
        borrow=new Borrow();
        borrow.setId(id);
        borrow.setState(state);

        if ("1".equals(borrow.getState())) {
            // 续借申请
            Borrow tempborrow = borrowService.selectBorrowById(id);
            borrow.setTempfinishdate(tempborrow.getFinishdate());
            borrow.setFinishdate(finishdate);
            borrow.setState("2");
            return toAjax(borrowService.updateBorrow(borrow));
        }else if ("3".equals(borrow.getState())) {
            // 还书申请
            borrow.setState("4");
            return toAjax(borrowService.updateBorrow(borrow));
        }
        return success();
    }


    /**
     * 审核
     */
    @PreAuthorize("@ss.hasPermi('work:borrow:check')")
    @Log(title = "借阅", businessType = BusinessType.UPDATE)
    @PutMapping("/check")
    public AjaxResult check(@RequestBody Borrow borrow)
    {
        String id = borrow.getId();
        String state = borrow.getState();
        String bookid = borrow.getBookid();
        borrow=new Borrow();
        borrow.setId(id);
        borrow.setState(state);

        if("0".equals(borrow.getState())) {
            // 借书审核通过
            borrow.setState("1");
            return toAjax(borrowService.updateBorrow(borrow));
        }else if ("2".equals(borrow.getState())) {
            // 续借审核通过
            borrow.setState("3");
            return toAjax(borrowService.updateBorrow(borrow));
        }else if ("4".equals(borrow.getState())) {
            // 还书审核通过
            borrow.setState("5");
            borrowService.updateBorrow(borrow);
            // 还书后修改图书状态
            Bookinfo bookinfo = new Bookinfo();
            bookinfo.setId(bookid);
            bookinfo.setBorrowstate("0");
            return toAjax(bookinfoService.updateBookinfo(bookinfo));
        }
        return success();
    }

    /**
     * 驳回申请
     */
    @PreAuthorize("@ss.hasPermi('work:borrow:check')")
    @Log(title = "借阅", businessType = BusinessType.UPDATE)
    @PutMapping("/reject")
    @Transactional
    public AjaxResult reject(@RequestBody Borrow borrow)
    {
        String id = borrow.getId();
        String state = borrow.getState();
        String bookid = borrow.getBookid();
        borrow=new Borrow();
        borrow.setId(id);
        borrow.setState(state);

        if("0".equals(borrow.getState())) {
            // 借书审核驳回
            Bookinfo bookinfo = new Bookinfo();
            bookinfo.setId(bookid);
            bookinfo.setBorrowstate("0");
            bookinfoService.updateBookinfo(bookinfo);
            borrowService.deleteBorrowById(id);
            return toAjax(1);
        }else if ("2".equals(borrow.getState())) {
            // 续借审核驳回
            Borrow tempborrow = borrowService.selectBorrowById(id);
            borrow.setFinishdate(tempborrow.getTempfinishdate());
            borrow.setState("1");
            return toAjax(borrowService.updateBorrow(borrow));
        }else if ("4".equals(borrow.getState())) {
            // 还书审核驳回
            borrow.setState("3");
            return toAjax(borrowService.updateBorrow(borrow));
        }
        return success();
    }
}
