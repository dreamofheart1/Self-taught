package com.ruoyi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

/**
 * 启动程序
 *
 * @author dream
 */
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
public class RuoYiApplication
{
    public static void main(String[] args)
    {
        // System.setProperty("spring.devtools.restart.enabled", "false");
        SpringApplication.run(RuoYiApplication.class, args);
        System.out.println("(♥◠‿◠)ﾉﾞ  启动成功   ლ(´ڡ`ლ)ﾞ  \n" +
                "      dBBBBb dBBBBBb    dBBBP dBBBBBb     dBBBBBBb   \n" +
                "         dBP     dBP               BB          dBP   \n" +
                "    dBP dBP  dBBBBK   dBBP     dBP BB   dBPdBPdBP    \n" +
                "   dBP dBP  dBP  BB  dBP      dBP  BB  dBPdBPdBP     \n" +
                "  dBBBBBP  dBP  dB' dBBBBP   dBBBBBBB dBPdBPdBP      \n" +
                "                                                    \n" +
                "    \n" +
                "    \n" +
                "    ");

    }
}
