package com.ruoyi.project.work.domain;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 图书馆对象 t_library
 *
 * @author dream
 * @date 2023-07-05
 */
public class Library extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private String id;

    /** 校区id */
    @Excel(name = "校区id")
    private String campusid;

    private String campusname;

    /** 代号 */
    @Excel(name = "代号")
    private String code;

    /** 图书馆名称 */
    @Excel(name = "图书馆名称")
    private String name;

    /** 更新时间戳 */
    private Date realtime;

    /** 创建时间 */
    private String createtime;

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }
    public void setCampusid(String campusid)
    {
        this.campusid = campusid;
    }

    public String getCampusid()
    {
        return campusid;
    }

    public String getCampusname() {
        return campusname;
    }

    public void setCampusname(String campusname) {
        this.campusname = campusname;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getCode()
    {
        return code;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
    public void setRealtime(Date realtime)
    {
        this.realtime = realtime;
    }

    public Date getRealtime()
    {
        return realtime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("campusid", getCampusid())
            .append("code", getCode())
            .append("name", getName())
            .append("createtime", getCreatetime())
            .append("realtime", getRealtime())
            .toString();
    }
}
