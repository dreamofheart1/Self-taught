package com.ruoyi.project.work.service.impl;

import java.util.List;

import com.ruoyi.common.utils.uuid.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.work.mapper.LayerMapper;
import com.ruoyi.project.work.domain.Layer;
import com.ruoyi.project.work.service.ILayerService;

/**
 * 层架Service业务层处理
 *
 * @author dream
 * @date 2023-07-05
 */
@Service
public class LayerServiceImpl implements ILayerService
{
    @Autowired
    private LayerMapper layerMapper;

    /**
     * 查询层架
     *
     * @param id 层架主键
     * @return 层架
     */
    @Override
    public Layer selectLayerById(String id)
    {
        return layerMapper.selectLayerById(id);
    }

    /**
     * 查询层架列表
     *
     * @param layer 层架
     * @return 层架
     */
    @Override
    public List<Layer> selectLayerList(Layer layer)
    {
        return layerMapper.selectLayerList(layer);
    }

    /**
     * 新增层架
     *
     * @param layer 层架
     * @return 结果
     */
    @Override
    public int insertLayer(Layer layer)
    {
        layer.setId(UUID.fastUUID().toString(true));
        return layerMapper.insertLayer(layer);
    }

    /**
     * 修改层架
     *
     * @param layer 层架
     * @return 结果
     */
    @Override
    public int updateLayer(Layer layer)
    {
        return layerMapper.updateLayer(layer);
    }

    /**
     * 批量删除层架
     *
     * @param ids 需要删除的层架主键
     * @return 结果
     */
    @Override
    public int deleteLayerByIds(String[] ids)
    {
        return layerMapper.deleteLayerByIds(ids);
    }

    /**
     * 删除层架信息
     *
     * @param id 层架主键
     * @return 结果
     */
    @Override
    public int deleteLayerById(String id)
    {
        return layerMapper.deleteLayerById(id);
    }
}
