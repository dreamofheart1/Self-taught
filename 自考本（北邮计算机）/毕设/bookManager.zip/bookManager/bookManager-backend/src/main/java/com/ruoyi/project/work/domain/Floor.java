package com.ruoyi.project.work.domain;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 楼层对象 t_floor
 *
 * @author dream
 * @date 2023-07-05
 */
public class Floor extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private String id;

    /** 图书馆id */
    @Excel(name = "图书馆id")
    private String libid;

    /** 图书馆名称 */
    private String libname;

    /** 代号 */
    @Excel(name = "代号")
    private String code;

    /** 楼层名称 */
    @Excel(name = "楼层名称")
    private String name;

    /** 排序 */
    @Excel(name = "排序")
    private Long orderid;

    /** 更新时间戳 */
    private Date realtime;

    /** 创建时间 */
    private String createtime;

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }
    public void setLibid(String libid)
    {
        this.libid = libid;
    }

    public String getLibid()
    {
        return libid;
    }

    public String getLibname() {
        return libname;
    }

    public void setLibname(String libname) {
        this.libname = libname;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getCode()
    {
        return code;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public Long getOrderid() {
        return orderid;
    }

    public void setOrderid(Long orderid) {
        this.orderid = orderid;
    }

    public void setRealtime(Date realtime)
    {
        this.realtime = realtime;
    }

    public Date getRealtime()
    {
        return realtime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("libid", getLibid())
            .append("code", getCode())
            .append("name", getName())
            .append("orderid", getOrderid())
            .append("createtime", getCreatetime())
            .append("realtime", getRealtime())
            .toString();
    }
}
