package com.ruoyi.project.work.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.enums.BusinessType;
import com.ruoyi.project.work.domain.Campus;
import com.ruoyi.project.work.service.ICampusService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.web.page.TableDataInfo;

/**
 * 校区Controller
 *
 * @author dream
 * @date 2023-07-05
 */
@RestController
@RequestMapping("/work/campus")
public class CampusController extends BaseController
{
    @Autowired
    private ICampusService campusService;

    /**
     * 查询校区列表
     */
    @PreAuthorize("@ss.hasPermi('work:campus:list')")
    @GetMapping("/list")
    public TableDataInfo list(Campus campus)
    {
        startPage();
        List<Campus> list = campusService.selectCampusList(campus);
        return getDataTable(list);
    }

    /**
     * 导出校区列表
     */
    @PreAuthorize("@ss.hasPermi('work:campus:export')")
    @Log(title = "校区", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Campus campus)
    {
        List<Campus> list = campusService.selectCampusList(campus);
        ExcelUtil<Campus> util = new ExcelUtil<Campus>(Campus.class);
        util.exportExcel(response, list, "校区数据");
    }

    /**
     * 获取校区详细信息
     */
    @PreAuthorize("@ss.hasPermi('work:campus:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(campusService.selectCampusById(id));
    }

    /**
     * 新增校区
     */
    @PreAuthorize("@ss.hasPermi('work:campus:add')")
    @Log(title = "校区", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Campus campus)
    {
        return toAjax(campusService.insertCampus(campus));
    }

    /**
     * 修改校区
     */
    @PreAuthorize("@ss.hasPermi('work:campus:edit')")
    @Log(title = "校区", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Campus campus)
    {
        return toAjax(campusService.updateCampus(campus));
    }

    /**
     * 删除校区
     */
    @PreAuthorize("@ss.hasPermi('work:campus:remove')")
    @Log(title = "校区", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(campusService.deleteCampusByIds(ids));
    }


    @GetMapping("/optionselect")
    public AjaxResult optionselect()
    {
        List<Campus> list = campusService.selectCampusList(null);
        return success(list);
    }
}
