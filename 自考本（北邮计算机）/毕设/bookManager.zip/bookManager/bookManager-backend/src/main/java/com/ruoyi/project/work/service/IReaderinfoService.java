package com.ruoyi.project.work.service;

import java.util.List;
import com.ruoyi.project.work.domain.Readerinfo;

/**
 * 读者Service接口
 *
 * @author dream
 * @date 2023-07-05
 */
public interface IReaderinfoService
{
    /**
     * 查询读者
     *
     * @param id 读者主键
     * @return 读者
     */
    public Readerinfo selectReaderinfoById(String id);

    Readerinfo selectReaderinfoByUserid(String userid);

    /**
     * 查询读者列表
     *
     * @param readerinfo 读者
     * @return 读者集合
     */
    public List<Readerinfo> selectReaderinfoList(Readerinfo readerinfo);

    /**
     * 新增读者
     *
     * @param readerinfo 读者
     * @return 结果
     */
    public int insertReaderinfo(Readerinfo readerinfo);

    /**
     * 修改读者
     *
     * @param readerinfo 读者
     * @return 结果
     */
    public int updateReaderinfo(Readerinfo readerinfo);

    /**
     * 批量删除读者
     *
     * @param ids 需要删除的读者主键集合
     * @return 结果
     */
    public int deleteReaderinfoByIds(String[] ids);

    /**
     * 删除读者信息
     *
     * @param id 读者主键
     * @return 结果
     */
    public int deleteReaderinfoById(String id);
}
