package com.ruoyi.project.work.service.impl;

import java.util.List;

import com.ruoyi.common.utils.uuid.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.work.mapper.BorrowMapper;
import com.ruoyi.project.work.domain.Borrow;
import com.ruoyi.project.work.service.IBorrowService;

/**
 * 借阅Service业务层处理
 *
 * @author dream
 * @date 2023-07-05
 */
@Service
public class BorrowServiceImpl implements IBorrowService
{
    @Autowired
    private BorrowMapper borrowMapper;

    /**
     * 查询借阅
     *
     * @param id 借阅主键
     * @return 借阅
     */
    @Override
    public Borrow selectBorrowById(String id)
    {
        return borrowMapper.selectBorrowById(id);
    }

    /**
     * 查询借阅列表
     *
     * @param borrow 借阅
     * @return 借阅
     */
    @Override
    public List<Borrow> selectBorrowList(Borrow borrow)
    {
        return borrowMapper.selectBorrowList(borrow);
    }

    /**
     * 新增借阅
     *
     * @param borrow 借阅
     * @return 结果
     */
    @Override
    public int insertBorrow(Borrow borrow)
    {
        borrow.setId(UUID.fastUUID().toString(true));
        return borrowMapper.insertBorrow(borrow);
    }

    /**
     * 修改借阅
     *
     * @param borrow 借阅
     * @return 结果
     */
    @Override
    public int updateBorrow(Borrow borrow)
    {
        return borrowMapper.updateBorrow(borrow);
    }

    /**
     * 批量删除借阅
     *
     * @param ids 需要删除的借阅主键
     * @return 结果
     */
    @Override
    public int deleteBorrowByIds(String[] ids)
    {
        return borrowMapper.deleteBorrowByIds(ids);
    }

    /**
     * 删除借阅信息
     *
     * @param id 借阅主键
     * @return 结果
     */
    @Override
    public int deleteBorrowById(String id)
    {
        return borrowMapper.deleteBorrowById(id);
    }
}
