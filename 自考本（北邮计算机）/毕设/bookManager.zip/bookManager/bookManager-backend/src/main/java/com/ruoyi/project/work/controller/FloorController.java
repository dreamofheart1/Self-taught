package com.ruoyi.project.work.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.enums.BusinessType;
import com.ruoyi.project.work.domain.Floor;
import com.ruoyi.project.work.service.IFloorService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.web.page.TableDataInfo;

/**
 * 楼层Controller
 *
 * @author dream
 * @date 2023-07-05
 */
@RestController
@RequestMapping("/work/floor")
public class FloorController extends BaseController
{
    @Autowired
    private IFloorService floorService;


    /**
     * 查询楼层列表
     */
    @PreAuthorize("@ss.hasPermi('work:floor:list')")
    @GetMapping("/list")
    public TableDataInfo list(Floor floor)
    {
        startPage();
        List<Floor> list = floorService.selectFloorList(floor);
        return getDataTable(list);
    }

    /**
     * 导出楼层列表
     */
    @PreAuthorize("@ss.hasPermi('work:floor:export')")
    @Log(title = "楼层", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Floor floor)
    {
        List<Floor> list = floorService.selectFloorList(floor);
        ExcelUtil<Floor> util = new ExcelUtil<Floor>(Floor.class);
        util.exportExcel(response, list, "楼层数据");
    }

    /**
     * 获取楼层详细信息
     */
    @PreAuthorize("@ss.hasPermi('work:floor:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(floorService.selectFloorById(id));
    }

    /**
     * 新增楼层
     */
    @PreAuthorize("@ss.hasPermi('work:floor:add')")
    @Log(title = "楼层", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Floor floor)
    {
        return toAjax(floorService.insertFloor(floor));
    }

    /**
     * 修改楼层
     */
    @PreAuthorize("@ss.hasPermi('work:floor:edit')")
    @Log(title = "楼层", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Floor floor)
    {
        return toAjax(floorService.updateFloor(floor));
    }

    /**
     * 删除楼层
     */
    @PreAuthorize("@ss.hasPermi('work:floor:remove')")
    @Log(title = "楼层", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(floorService.deleteFloorByIds(ids));
    }

    @GetMapping("/optionselect")
    public AjaxResult optionselect()
    {
        List<Floor> list = floorService.selectFloorList(null);
        return success(list);
    }
}
